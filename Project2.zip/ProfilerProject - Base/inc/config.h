#ifndef CONFIG_H
#define CONFIG_H

#define NUM_TESTS 10000

#endif // CONFIG_H
