#ifndef DELAY_H
#define DELAY_H
extern void Delay(uint32_t dlyTicks);

#endif
// *******************************ARM University Program Copyright � ARM Ltd 2013*************************************   
